
package com.example.orderservice.service;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;
import com.example.orderservice.entity.*;
import com.example.orderservice.repository.OrderRepository;
import com.example.orderservice.dto.*;
import com.example.orderservice.client.ProductClient;
@Service
public class OrderService {
 @Autowired private OrderRepository repo;
 @Autowired private ProductClient productClient;
 public Order placeOrder(PlaceOrderRequest req){
  Order order=new Order();
  order.setUserId(req.userId);
  order.setStatus("PLACED");
  List<OrderItem> items=new ArrayList<>();
  double total=0;
  for(OrderItemRequest r:req.items){
   double price=productClient.getPrice(r.productId);
   OrderItem i=new OrderItem();
   i.setProductId(r.productId);
   i.setQuantity(r.quantity);
   i.setPrice(price*r.quantity);
   i.setOrder(order);
   total+=i.getPrice();
   items.add(i);
  }
  order.setTotalAmount(total);
  order.setOrderItems(items);
  return repo.save(order);
 }
 public List<Order> getOrders(Long userId){
  return repo.findByUserId(userId);
 }
}
