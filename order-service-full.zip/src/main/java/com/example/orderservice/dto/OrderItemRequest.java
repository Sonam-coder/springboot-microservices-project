
package com.example.orderservice.dto;
public class OrderItemRequest {
 public Long productId;
 public int quantity;
}
