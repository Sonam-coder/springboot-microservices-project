
package com.example.orderservice.dto;
import java.util.List;
public class PlaceOrderRequest {
 public Long userId;
 public List<OrderItemRequest> items;
}
