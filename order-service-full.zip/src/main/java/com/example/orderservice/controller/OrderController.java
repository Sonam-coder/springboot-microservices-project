
package com.example.orderservice.controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import com.example.orderservice.entity.Order;
import com.example.orderservice.service.OrderService;
import com.example.orderservice.dto.PlaceOrderRequest;
@RestController
@RequestMapping("/orders")
public class OrderController {
 @Autowired private OrderService service;
 @PostMapping
 public Order place(@RequestBody PlaceOrderRequest r){
  return service.placeOrder(r);
 }
 @GetMapping("/user/{id}")
 public List<Order> byUser(@PathVariable Long id){
  return service.getOrders(id);
 }
}
