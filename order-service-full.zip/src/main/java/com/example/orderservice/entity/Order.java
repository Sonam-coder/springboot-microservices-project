
package com.example.orderservice.entity;
import javax.persistence.*;
import java.util.List;
@Entity
@Table(name="orders")
public class Order {
 @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
 private Long id;
 private Long userId;
 private double totalAmount;
 private String status;
 @OneToMany(mappedBy="order", cascade=CascadeType.ALL)
 private List<OrderItem> orderItems;
}
