
package com.example.orderservice.client;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import java.util.Map;
@Component
public class ProductClient {
 private final RestTemplate restTemplate = new RestTemplate();
 public double getPrice(Long productId){
  Map m = restTemplate.getForObject("http://localhost:8082/products/"+productId, Map.class);
  return Double.parseDouble(m.get("price").toString());
 }
}
