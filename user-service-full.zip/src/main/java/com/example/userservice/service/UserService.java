
package com.example.userservice.service;
import org.springframework.stereotype.Service;
@Service
public class UserService {
}
