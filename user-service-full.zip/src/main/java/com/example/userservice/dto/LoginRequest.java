
package com.example.userservice.dto;
public class LoginRequest {
public String email;
public String password;
}
