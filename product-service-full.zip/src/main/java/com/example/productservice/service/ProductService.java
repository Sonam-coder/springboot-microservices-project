
package com.example.productservice.service;
import org.springframework.stereotype.Service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import com.example.productservice.repository.ProductRepository;
import com.example.productservice.entity.Product;
@Service
public class ProductService {
 @Autowired
 private ProductRepository repo;
 public Product save(Product p){ return repo.save(p); }
 public List<Product> findAll(){ return repo.findAll(); }
}
