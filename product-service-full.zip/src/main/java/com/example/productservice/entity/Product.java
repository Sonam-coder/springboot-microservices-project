
package com.example.productservice.entity;
import javax.persistence.*;
@Entity
public class Product {
 @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
 private Long id;
 private String name;
 private double price;
 private int stock;
}
